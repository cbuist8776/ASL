'''
Chadwick Buist
12/12/2015
DPW-Online
Reusable Library
'''

import webapp2
#Imports are set up to import functionality from FormPage and ResultsPage Classes from pages.py file to the MainHandler Class
# imports from Conversions function in library.py file to the MainHandler class.
from pages import FormPage, ResultsPage
from library import Conversions
#import mysql.connector


class MainHandler(webapp2.RequestHandler):
    def get(self):
		        
        #variables set for invoking functions, etc from FormPage class and ResultsPage class, and Conversions class
        p = FormPage()
        
        q = ResultsPage()
        
        lib = Conversions()
        
       
        
        
        

        
        #stores the first name, last name, email, 50 time, and 25 time from the form
        #stores the conversions that are invoked from the pages.py file to pull the originally submitted times and then to
        #convert them and show them to the user.
        # q.etc is invoking variables that are needed to further output the results to the user.
        #else write the original html in the head, body, and close
        
        if self.request.GET:
            first = self.request.GET['first']
            last = self.request.GET['last']
            email = self.request.GET['email']
            time1 = self.request.GET['50time']
            time2 = self.request.GET['25time']
            conversion1 = float(self.request.GET['50time'])
            a = lib.convert1(conversion1)
            conversion2 = float(self.request.GET['50time'])
            b = lib.convert2(conversion2)
            conversion3 = float(self.request.GET['25time'])
            c = lib.convert3(conversion3)
            conversion4 = float(self.request.GET['25time'])
            d = lib.convert4(conversion4)
            q.first1(first)
            q.last1(last)
            q.exchange1(a)
            q.exchange2(b)
            q.exchange3(c)
            q.exchange4(d)

            self.response.write(q.print_out())
            #self.response.write(q.head2 + q.body2 + q.close2)
        else:
            self.response.write(p.head + p.body + p.close)
            
            
            



#	mysql = mysql.connector.connect(user='root', password='root', host='127.0.0.1',port='8889', database='ASL')

#	cursor = mysql.cursor()

#	query=("select * from test")

#	cursor.execute(query)

#	for (a) in cursor:
#		print("Hello {}".format(a))
#	cursor.close()
#	mysql.close()


            
            

            


		


app = webapp2.WSGIApplication([
    ('/', MainHandler)
], debug=True)
     