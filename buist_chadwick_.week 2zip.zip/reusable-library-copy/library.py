#Conversions class set up in the library to later be invoked in MainHandler.

# init function that is initially set up to set conversionfirst and conversionsecond attributes to private so they can only be changed by
#the user's initial input or by the admin.

class Conversions(object):
    def __init__(self):
        
   
      
      self.__conversionfirst = ''
      self.__conversionsecond = ''
      
    
 
   
 # functions/methods set up below to define the invokations that will be used in MainHandler and to give them the proper numbers to use
# in the equations to make the conversions.
# They also have the print and return commands to release the information to be utilizied later in the invokations in MainHandler
      
       
    def convert1(self,conversion1):
        fiftyydstomsc = conversion1 * 1.11
        
        print fiftyydstomsc        
        return fiftyydstomsc
    
    
    def convert2(self,conversion2):
        fiftyydstomlc = conversion2 * 1.11 + 0.8
        print fiftyydstomlc
        return fiftyydstomlc
    
        
    
    def convert3(self,conversion3):
        twentyfiveydstomsc = conversion3 * 1.11
        print twentyfiveydstomsc
        return twentyfiveydstomsc
    
       
    
    def convert4(self,conversion4):
        twentyfiveydstomlc = conversion4 * 1.11 + 0.8
        print twentyfiveydstomlc
        return twentyfiveydstomlc
    
    #Getters and setters used to get the information and set it to make it readable and writible from the private attributes set above at the beginning of the code.
    #  The variables fifty_original and twenty_five_original will represent the initial times submitted into the form to be properly utilized
    #later in the equations and invocations.

    @property
    def conversionfirst(self):
        return self.__conversion1
    
    @conversionfirst.setter
    def conversionfirst(self, fifty_original):
        self.__conversion1 = fifty_original
        
    @property
    def conversionsecond(self):
        return self.__conversion2
    
    @conversionsecond.setter
    def conversionsecond(self, twenty_five_original):
        self.__conversion2 = twenty_five_original
        
        
        
        








