from flask import Flask, render_template



# Class FormPage used with the __init function to pull the title, css styling, and set up the html for the site that has the form
# taking in the information from the user.
#form code are using the GET methods to pull in the information to later be used in the equations used in the functions below and to be invoked in Main later.

class FormPage(object):
    def __init__(self):
        self.title = "Enter Your Information Please"
        self.css = "css/styles3.css"
        self.head = """
        
app = Flask(__name__)

@app.route("/form")
def form():
	return render_template("form.html")


if __name__ == "__main__":
	app.run()

"""
        


        # print_out function to print out the information for the head, body, and close which is also invoked later in MainHandler.
        
    def print_out(self):
        all = self.head + self.body + self.close
        all = all.format(**locals())
        return all

# ResultsPage Class used to set variables to be used in showing the results from the equations created in the functions below the __init function.

class ResultsPage(object):
    def __init__(self):

        self.title2 = "Data"
        self.css2 = "css/styles.css"
        self.free1 = "a"
        self.free2 = "b"
        self.free3 = "c"
        self.free4 = "d"
        self.first = "e"
        self.last = "f"
        self.head2 = """


# HTML used to initially show the information that is converted and displayed to the user.
   
<!DOCTYPE HTML>
<html>
   <head>
       <title>Enter your information:</title>
       <link href="css/styles.css" rel="stylesheet" type="text/css" />
   </head>
   <body>
   
  <!--Results HTML info -->
  
  <p> Hi {self.first}  + {self.last}. </p>
  
  
  
  <p> Your converted times are: </p>
  
  <p> 50 meter short course: {self.free1}  </p>
  
  <p> 50 meter long course: {self.free2} </p>
  
  <p> 25 meter short course: {self.free3} </p>
  
  <p> 25 meter long course: {self.free4} </p>
  
  <p> Congratulations on your times!</p>
       
       
       """

        self.body2 = ""
        self.close2 = """
   </body>
</html>
       """

# equations created in fuctions that take the variable and utilize the free1, free2, free3, and free4 conversions.
# these equations will take in the original times submitted and convert them to the new times that will later be invoked
# in MainHandler and displayed to the user.

    def exchange1(self,a):
        self.free1 = a
        print self.free1
        return self.free1

    def exchange2(self,b):
        self.free2 = b
        print self.free2
        return self.free2

    def exchange3(self,c):
        self.free3 = c
        print self.free3
        return self.free3

    def exchange4(self,d):
        self.free4 = d
        print self.free4
        return self.free4

    def first1(self,e):
        self.first = e
        print self.first
        return self.first

    def last1(self,f):
        self.last = f
        print self.last
        return self.last

    def print_out(self):
        all = self.head2 + self.body2 +self.close2
        all = all.format(**locals())
        return all
